<?php

/*
 * CONFIG!
 * EDIT ALL THE NECESSARY VALUES WITHIN THIS PART!
 */
//http://localhost:8081/generate.php
//https://airduino-ph.000webhostapp.com/generate.php
// Please check if the location of the keys.php and db.php files are correct.
// Double-check or else the entire script will not work.
require_once("_system/keys.php");
require_once("_system/db.php");

$device_id = "DASMA"; // The exact device_id in the DB
$total = 1; // Total entries to be added. DO NOT PUT HIGH NUMBER. IT MIGHT CRASH THE SERVER!!!
$selected_date = "January 25, 2019 12:00:00 PM"; // Start date and time
$time_increments = "+1 hours"; // Time increments. Must be in such format!


// Temperature Min-Max
$minTemp = 31;
$maxTemp = 33;

// Humidity Min-Max
$minHumid = 31;
$maxHumid = 35;

// Air Min-Max
$minAir =80;
$maxAir =89;
$descAir = "Moderate"; // Keep within the description range.

/*
 * !!! RUN THE SCRIPT AFTER EDITING THE VALUES ABOVE!!!
 * 
 * MAKE SURE TO BACK-UP ALL DATABASE DATA BEFORE RUNNING THE SCRIPT
 * 
 * THIS IS A DANGEROUS ACTION AND CAN DESTROY THE DATABASE IF SOMETHING FAILS
 * WHILE THE SCRIPT IS BEING EXECUTED!
 */

/*
 * DO NOT EDIT ANYTHING BEYOND THIS POINT!
 * 
 * DO
 * 
 * NOT
 * 
 * EDIT
 * 
 * ANYTHING
 * 
 * BELOW!
 * 
 */




/*
 * EDITING
 * 
 * ANYTHING
 * 
 * BELOW
 * 
 * MAY
 * 
 * DESTROY
 * 
 * THE
 * 
 * CURRENT
 * 
 * DATABASE 
 * 
 * ENTRIES
 * 
 */

date_default_timezone_set("Asia/Manila"); // Set the correct timezone if needed
$lastdate = date("Y-m-d H:i:s",strtotime($selected_date)); // Initialize time based on set value

$num = 0; // Initialization var for the count

// Define sql query for temperature
function addTemp($mysqli,$device_id,$value,$timestamp){
    $stmt = $mysqli->prepare("INSERT INTO `temperature`(`device_id`,`value`,`timestamp`) VALUES (?,?,?)");
    $stmt->bind_param("sss",$device_id,$value,$timestamp);
    $stmt->execute();
}

// Define sql query for humidity
function addHumid($mysqli,$device_id,$value,$timestamp){
    $stmt = $mysqli->prepare("INSERT INTO `humidity`(`device_id`,`value`,`timestamp`) VALUES (?,?,?)");
    $stmt->bind_param("sss",$device_id,$value,$timestamp);
    $stmt->execute();
}

// Define sql query for air quality
function addAir($mysqli,$device_id,$value,$description,$timestamp){
    $stmt = $mysqli->prepare("INSERT INTO `air_quality`(`device_id`,`value`,`description`,`timestamp`) VALUES (?,?,?,?)");
    $stmt->bind_param("ssss",$device_id,$value,$description,$timestamp);
    $stmt->execute();
}

// Loop along count
while($num !== $total){

    // Generate the values
    if($num !== 0) $lastdate = date("Y-m-d H:i:s", strtotime("$lastdate $time_increments"));        
    $temp_value = rand($minTemp,$maxTemp);
	$humid_value = rand($minHumid,$maxHumid);
	$air_value = rand($minAir,$maxAir);
	
	addTemp($mysqli,$device_id,$temp_value,$lastdate);
	addHumid($mysqli,$device_id,$humid_value,$lastdate);
	addAir($mysqli,$device_id,$air_value,$descAir,$lastdate);
    
    echo "Added data for $lastdate<br>";
    
    $num++;
    
}


?>