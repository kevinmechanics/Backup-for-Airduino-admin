<?php
session_start();

if(empty($_SESSION['loggedin'])) die("Unauthorized");

require_once("../../_system/keys.php");
require_once("../../_system/db.php");
require_once("../../class/Temperature.class.php");
require_once("../../class/Humidity.class.php");
require_once("../../class/AirQuality.class.php");

$id1="0";
$id2="0";
$id3="0";

$obj1 = new Temperature($mysqli);
$obj2 = new Humidity($mysqli);
$obj3 = new AirQuality($mysqli);

if(!empty($_GET['id1'])) $id1 = strip_tags($_GET['id1']);
if(!empty($_GET['id2'])) $id2 = strip_tags($_GET['id2']);
if(!empty($_GET['id3'])) $id3 = strip_tags($_GET['id3']);
	
if(!empty($id1)) $obj1->delete($id1);
if(!empty($id2))$obj2->delete($id2);
if(!empty($id3))$obj3->delete($id3);

header("Location: ".$_SERVER['HTTP_REFERER']);

?>