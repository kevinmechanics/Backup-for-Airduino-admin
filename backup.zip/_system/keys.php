<?php

// DB
$sql_host = "localhost";
$sql_username = "id8022293_airduino_ph";
$sql_password = "airduino";
$sql_database = "id8022293_airduino_db";


?>
