<?php

// DB
$sql_host = "";
$sql_username = "";
$sql_password = "";
$sql_database = "airduino";

?>
