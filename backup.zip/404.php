<!Doctype html>
<html>
	<head>
		<title>Airduino</title>
		<meta charset="UTF-8">
		<meta name="theme-color" content="#2196F3">
		<link rel="stylesheet" href="/admin/styles/style.css">
	</head>
	<body>
		<nav>
			<a class="title" href="#!"><b>Airduino</b></a>
		</nav>
		<br><br>
		<div style="margin: 0 auto; max-width: 1280px; width: 90%; ">
			<h1>Page Not Found!</h1>
			<br>
			<p>The page you are looking for cannot be found in our site.</p>
		</div>
	</body>
</html>