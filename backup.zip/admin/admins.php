<?php
session_start();
if(empty($_SESSION['loggedin'])) header('Location: /admin/login.php');

@$AdminObject = $_SESSION['AdminObject'];

$admin_name = "Anonymous";
$admin_username = "username";

if(@$AdminObject){
	$admin_name = @$AdminObject['name'];
	$admin_username = @$AdminObject['username'];
}

require_once("../_system/keys.php");
require_once("../_system/db.php");
require_once("../class/Admin.class.php");

$admin = new Admin($mysqli);

$admin_list = $admin->getAll();
$output = " ";	
if (!empty($_GET['by'])){
	
					//create connection
					//mysqli_connect('localhost', 'id8022293_airduino_ph', 'airduino');
					$mysqli = new mysqli("localhost", "id8022293_airduino_ph", "airduino", "id8022293_airduino_db"); //for web
				//	$mysqli = new mysqli("localhost:3306", "root", "", "id8022293_airduino_db"); // for local

					
					// Check if empty query
					if(empty($_GET['by'])){
						$result = $mysqli->query("SELECT * FROM administrator");
					} else {
								// Handle GET data
								$query = $_GET['by'];
								// Make Query
								$result = $mysqli->query("SELECT * FROM administrator WHERE name LIKE '$query%' or username LIKE '$query%'");
								$count = mysqli_num_rows($result);
								
								if($count == 0){
								  $output = "No search result found!";
								  $admin_list = array();

								}else{
								 $admin_list = array();
								   
								  while ($row = mysqli_fetch_array($result)) {

									$name = $row ['name'];
									$username = $row ['username'];
									$id = $row ['id'];
									
									$temp_array = array(
										"name" => $name,
										"username" => $username,
										"id" => $id
									);
									
									$admin_list[] = $temp_array;
								  }

								}						
							}
							
}
else{
	$admin_list = $admin->getAll();
}
// Sorting Process
$b_n = '';
$b_u = '';

$s = 'selected';

if(empty($_GET['by'])){
} else {
	$by = $_GET['by'];
	switch($by){
		case("name"):
			$b_n = $s;
			break;
		case("username"):
			$b_u = $s;
			break;
	
	}
}


?>

<!Doctype html>
<html>
		<head><link rel="icon" type="image/png" href="/static/logo.png">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<title>Admin - Airduino</title>
		<meta charset="UTF-8">
        <meta name="theme-color" content="#1E90FF">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="/admin/styles/style1.css">
	</head>
	<body>
<nav>
			<div class="w3-sidebar w3-bar-block w3-border-right w3-animate-left w3-animate-opacity showvisible" style="display:none" id="mySidebar">
				  <button onclick="w3_close()" class="w3-bar-item w3-large" style="padding: 13px 16px" >Close &times;</button>	
				  <a href="/admin/index.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Home</a>	
				  <a href="/admin/alerts.php" class="w3-bar-item w3-button waves-teal" style="padding: 13px 16px">Alerts</a>
				  <a href="/admin/devices.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Devices</a>	
				  <a href="/admin/graphs.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Graphs</a>
		  
				  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc1()" style="padding: 13px 14px">
						Accounts <i class="fa fa-caret-down"></i>
				  </button>
				  
				  <div id="demoAcc1" class="w3-hide w3-white w3-card w3-bar-block" style="padding: 13px 16px">
			      <a href="/admin/account_edit.php" class="w3-bar-item w3-button" style="padding: 13px 16px">My Account</a>
				  <a href="/admin/users.php" class="w3-bar-item w3-button" style="padding: 13px 16px">User Accounts</a>
				  <a href="/admin/admins.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Admin Accounts</a>
				  </div>					 
				  
				  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc2()" style="padding: 13px 14px">
						Customer Support <i class="fa fa-caret-down"></i>
				  </button>
				  
				  <div id="demoAcc2" class="w3-hide w3-white w3-card w3-bar-block" style="padding: 13px 16px">
					  <a href="https://mail.google.com/mail/#inbox" target="_blank" class="w3-bar-item w3-button">Gmail</a>
					  <a href="https://docs.google.com/forms/d/1yTVAoG4DCxKHlB36bUfd1DEY-M5lx6QT_QCDS7YlzEI/edit" target="_blank" class="w3-bar-item w3-button">Feed Back</a>					  
					  <a href="https://docs.google.com/forms/d/1Z9IXTk5ZS09Dmg0JOhOOF_QFQrnD4XnRLbTvBSpDdss/edit" target="_blank" class="w3-bar-item w3-button">Forgot password</a>					  
					  <a href="https://docs.google.com/forms/d/11UlmpDHvrJHNCP5Dq6stXaY_p_keQvWi1EOXcxjLwMw/edit" target="_blank" class="w3-bar-item w3-button">Report The problem</a>	
				  </div>	
				  <a href="/admin/logout.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Sign Out</a>
			</div>

		<div class="navbar1">
			  <button class="w3-button w3-blue w3-xlarge" onclick="w3_open()">☰</button>
			 <a class="title" href="/admin/index.php"><b>Airduino</b> Admin </a>	

		</div>		
	
 </nav>     
		<div>
				
			<div class="row">	
			
			
			<div class="col s13">
				<form method="get" action="">
					
					<input class="searchTerm" type="text" name="by" placeholder="Search">

					<button type="submit"  style="border-radius: 0rem 3rem 3rem 0rem" class="btn_search "><i id="btnicon" class="material-icons">search</i></button>
				</form>
			<h4><?php echo $output; ?></h4>
			</div>			
			
				<div class="col s14">
					<h3>Admins</h3> <a href="/admin/admins_add.php" class="btn waves-effect waves-light btn_small pulse">ADD <b>+</b></a>
					<table class="responsive-table highlight striped">
						<thead>
							<tr>
								<th>Name</th>
								<th>Username</th>
								<th>Edit</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
						<?php
							foreach($admin_list as $a){
								$id = $a['id'];
								$name = $a['name'];
								$username = $a['username'];
                                
                                if($username == $admin_username){
                                    
                                echo "
								<tr>
									<td>$name</td>
									<td>$username</td>
									<td>
										<a style='color:blue;'href='/admin/admins_edit.php?id=$id'><i class='material-icons icnedit'>mode_edit</i></a>
									</td>
										<td>	
											<a style='color:grey;' onclick='alert(\"Cannot delete your own account\")' href='#!'> <i class='material-icons icndelete remove'>not_interested</i></a>
										</td>
								</tr>
								";    
                                    
                                } else {
                                    
                                echo "
								<tr>
									<td>$name</td>
									<td>$username</td>
									<td>
										<a style='color:blue;'href='/admin/admins_edit.php?id=$id'><i class='material-icons icnedit'>mode_edit</i></a>
									</td>
										<td>	
											<a style='color:red;' onclick='deleteDevice($id)' href='#!'> <i class='material-icons icndelete remove'>delete_forever</i></a>
										</td>
								</tr>
								";
                                    
                                }
								
							}	
						?>
						</tbody>
					</table>					
				</div>
			</div>
		</div>
		
		
	<script>
			function w3_open() {
			  document.getElementById("mySidebar").style.display = "block";
			}

			function w3_close() {
			  document.getElementById("mySidebar").style.display = "none";
			}
	</script>
	<script>
        let deleteDevice = (id)=>{
            if(!id){
        	    alert('Device ID is Required');
            } else {
            
            	var answer = confirm('Are you sure you want to delete the Admin User?');
            	
                if(answer){
                	location.replace(`/api/admin/delete.php?id=${id}`);
                }
                
            }
        };
    </script>
		<script>
			function myAccFunc1() {
			  var x = document.getElementById("demoAcc1");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-blue";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-blue", "");
			  }
			}
			
						function myAccFunc2() {
			  var x = document.getElementById("demoAcc2");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-blue";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-blue", "");
			  }
			}
			
			function myDropFunc() {
			  var x = document.getElementById("demoDrop");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-green";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-green", "");
			  }
			}
		</script>
	</body>
</html>