<?php
session_start();

if(empty($_SESSION['loggedin'])) header('Location: /admin/login.php');

@$AdminObject = $_SESSION['AdminObject'];

$admin_name = "Anonymous";
$admin_username = "username";

if(@$AdminObject){
	$admin_name = @$AdminObject['name'];
	$admin_username = @$AdminObject['username'];
}

$id = $_GET['id'];

require_once("../_system/keys.php");
require_once("../_system/db.php");
require_once("../class/Device.class.php");

$device_obj = new Device($mysqli);

$device_info = $device_obj->get($id);
if(empty($device_info)) die("Device not found");

?>
<!Doctype html>
<html>
	<head>
		<link rel="icon" type="image/png" href="/static/logo.png">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<title>Admin - Airduino</title>
		<meta charset="UTF-8">
        <meta name="theme-color" content="#1E90FF">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="/admin/styles/style1.css">
	</head>
	<body>
<nav>
			<div class="w3-sidebar w3-bar-block w3-border-right w3-animate-left w3-animate-opacity showvisible" style="display:none" id="mySidebar">
				  <button onclick="w3_close()" class="w3-bar-item w3-large" style="padding: 13px 16px" >Close &times;</button>	
				  <a href="/admin/index.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Home</a>	
				  <a href="/admin/alerts.php" class="w3-bar-item w3-button waves-teal" style="padding: 13px 16px">Alerts</a>
				  <a href="/admin/devices.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Devices</a>	
				  <a href="/admin/graphs.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Graphs</a>
		  
				  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc1()" style="padding: 13px 14px">
						Accounts <i class="fa fa-caret-down"></i>
				  </button>
				  
				  <div id="demoAcc1" class="w3-hide w3-white w3-card w3-bar-block" style="padding: 13px 16px">
			      <a href="/admin/account_edit.php" class="w3-bar-item w3-button" style="padding: 13px 16px">My Account</a>
				  <a href="/admin/users.php" class="w3-bar-item w3-button" style="padding: 13px 16px">User Accounts</a>
				  <a href="/admin/admins.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Admin Accounts</a>
				  </div>					 
				  
				  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc2()" style="padding: 13px 14px">
						Customer Support <i class="fa fa-caret-down"></i>
				  </button>
				  
				  <div id="demoAcc2" class="w3-hide w3-white w3-card w3-bar-block" style="padding: 13px 16px">
					  <a href="https://mail.google.com/mail/#inbox" target="_blank" class="w3-bar-item w3-button">Gmail</a>
					  <a href="https://docs.google.com/forms/d/1yTVAoG4DCxKHlB36bUfd1DEY-M5lx6QT_QCDS7YlzEI/edit" target="_blank" class="w3-bar-item w3-button">Feed Back</a>					  
					  <a href="https://docs.google.com/forms/d/1Z9IXTk5ZS09Dmg0JOhOOF_QFQrnD4XnRLbTvBSpDdss/edit" target="_blank" class="w3-bar-item w3-button">Forgot password</a>					  
					  <a href="https://docs.google.com/forms/d/11UlmpDHvrJHNCP5Dq6stXaY_p_keQvWi1EOXcxjLwMw/edit" target="_blank" class="w3-bar-item w3-button">Report The problem</a>
				  </div>	
				  <a href="/admin/logout.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Sign Out</a>
			</div>

		<div class="navbar1">
			  <button class="w3-button w3-blue w3-xlarge" onclick="w3_open()">☰</button>
			 <a class="title" href="/admin/index.php"><b>Airduino</b> Admin </a>	
		</div>			 
 </nav>  
		<div>
			<div class="row">

				<div class="col s13">
					<h3>Devices > Edit</h3> 
					<?php if(!empty($_GET['msg'])) echo $_GET['msg'] . "<br><br>"; ?>
					<a href="/admin/devices.php" class="btn waves-effect waves-blue btn_small pulse">&lt; Back</a>
					<br><br>
					<form method="POST" action="../api/device/edit.php?id=<?php echo $id; ?>">
					<i data-tooltip="DEVICE ID" class="material-icons prefix tooltip-right">perm_device_information</i>
					<br>
						<input type="text" name="device_id" placeholder="Device ID" style="width:60%" value="<?php echo $device_info['device_id']; ?>" required>
					<br>	
					<i data-tooltip="LOCATION" class="material-icons prefix tooltip-right">location_on</i>	
					<br>						
						<input type="text" name="location" placeholder="Location" style="width:60%" value="<?php echo $device_info['location']; ?>" required>
					<br>	
					<i data-tooltip="CITY" class="material-icons prefix tooltip-right ">location_city</i>
					<br>						
						<input type="text" name="city" placeholder="City" style="width:60%" value="<?php echo $device_info['city']; ?>" required>
					<br>	
					<i data-tooltip="CONTACTS" class="material-icons prefix tooltip-right">contacts</i>
					<br>						
						<input type="text" name="mobile_number" placeholder="Mobile Number" style="width:60%" value="<?php echo $device_info['mobile_number']; ?>" required>
						
						<br><br>
						<button type="submit" class="btn btnhover">Edit</button>
					</form>
				</div>
			</div>
		</div>
		<script>
			function w3_open() {
			  document.getElementById("mySidebar").style.display = "block";
			}

			function w3_close() {
			  document.getElementById("mySidebar").style.display = "none";
			}
	    </script>
		<script>
			function myAccFunc1() {
			  var x = document.getElementById("demoAcc1");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-blue";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-blue", "");
			  }
			}
			
						function myAccFunc2() {
			  var x = document.getElementById("demoAcc2");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-blue";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-blue", "");
			  }
			}
			
			function myDropFunc() {
			  var x = document.getElementById("demoDrop");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-green";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-green", "");
			  }
			}
		</script>	
	</body>
</html>