<?php

session_start();

if(empty($_SESSION['loggedin'])) header('Location: /admin/login.php');

@$AdminObject = $_SESSION['AdminObject'];

$admin_name = "Anonymous";
$admin_username = "username";

if(@$AdminObject){
	$admin_name = @$AdminObject['name'];
	$admin_username = @$AdminObject['username'];
}

// Get db keys
require_once("../_system/keys.php");
// include db object
require_once("../_system/db.php");

// require function
require_once("getgraphs.php");

// include classes
require_once("../class/Device.class.php");
require_once("../class/Temperature.class.php");
require_once("../class/Humidity.class.php");
require_once("../class/AirQuality.class.php");

// create objects
$device = new Device($mysqli);
$temperature = new Temperature($mysqli);
$humidity = new Humidity($mysqli);
$airquality = new AirQuality($mysqli);


$device_list = $device->getAll();
?>

<!Doctype html>
<html>
	<head>
		<link rel="icon" type="image/png" href="/static/logo.png">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">	
		<title>Admin - Airduino</title>
		<meta charset="UTF-8">
        <meta name="theme-color" content="#1E90FF">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link rel="stylesheet" href="/admin/styles/style1.css">
		<script type="text/javascript" src="https://www.google.com/jsapi"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.min.js"></script>
	</head>
	<body id="change">
	
		<nav>
			<div class="w3-sidebar w3-bar-block w3-border-right w3-animate-left w3-animate-opacity showvisible" style="display:none" id="mySidebar">
				  <button onclick="w3_close()" class="w3-bar-item w3-large" style="padding: 13px 16px" >Close &times;</button>	
				  <a href="/admin/index.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Home</a>	
				  <a href="/admin/alerts.php" class="w3-bar-item w3-button waves-teal" style="padding: 13px 16px">Alerts</a>
				  <a href="/admin/devices.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Devices</a>	
				  <a href="/admin/graphs.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Graphs</a>
		  
				  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc1()" style="padding: 13px 14px">
						Accounts <i class="fa fa-caret-down"></i>
				  </button>
				  
				  <div id="demoAcc1" class="w3-hide w3-white w3-card w3-bar-block" style="padding: 13px 16px">
			      <a href="/admin/account_edit.php" class="w3-bar-item w3-button" style="padding: 13px 16px">My Account</a>
				  <a href="/admin/users.php" class="w3-bar-item w3-button" style="padding: 13px 16px">User Accounts</a>
				  <a href="/admin/admins.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Admin Accounts</a>
				  </div>					 
				  
				  <button class="w3-button w3-block w3-left-align" onclick="myAccFunc2()" style="padding: 13px 14px">
						Customer Support <i class="fa fa-caret-down"></i>
				  </button>
				  
				  <div id="demoAcc2" class="w3-hide w3-white w3-card w3-bar-block" style="padding: 13px 16px">
					  <a href="https://mail.google.com/mail/#inbox" target="_blank" class="w3-bar-item w3-button">Gmail</a>
					  <a href="https://docs.google.com/forms/d/1yTVAoG4DCxKHlB36bUfd1DEY-M5lx6QT_QCDS7YlzEI/edit" target="_blank" class="w3-bar-item w3-button">Feed Back</a>					  
					  <a href="https://docs.google.com/forms/d/1Z9IXTk5ZS09Dmg0JOhOOF_QFQrnD4XnRLbTvBSpDdss/edit" target="_blank" class="w3-bar-item w3-button">Forgot password</a>					  
					  <a href="https://docs.google.com/forms/d/11UlmpDHvrJHNCP5Dq6stXaY_p_keQvWi1EOXcxjLwMw/edit" target="_blank" class="w3-bar-item w3-button">Report The problem</a>	
				  </div>	
				  <a href="/admin/logout.php" class="w3-bar-item w3-button" style="padding: 13px 16px">Sign Out</a>
			</div>

			<div class="navbar">
				 <button class="w3-button w3-blue w3-xlarge " onclick="w3_open()">☰</button>
				 <a class="title" href="/admin/index.php"><b>Airduino</b> Admin </a>	
			</div>			 
		 </nav>   
		 
		 <style>
			.card {
				padding: 20px;
			}
			h2 {
				padding-left: 30px;
			}
			.cards-container {
			 padding-left:10px;   
			    
			}
		 </style>
		 <div>
		 <h2>Graph</h2>
		 
		 <div class="cards-container" width="100%">
			<?php
				foreach($device_list as $d){
					$di = $d['device_id'];
					$l = $d['location'];
					$c = $d['city'];
					$data = getAllData($temperature,$humidity,$airquality,$di);
					//$data = array_reverse($data);
					$data = array_splice($data,29);
					$timestamps = array();
					$tempData = array();
					$humidData = array();
					$airData = array();
					foreach($data as $td){
						if(!empty($td['temperature'])){
							if(count($tempData) !== 50){
								$timestamps[] = $td['timestamp'];
								$tempData[] = $td['temperature'];
								$humidData[] = $td['humidity'];
								$airData[] = $td['air_value'];
							}
						}
					}
					$timestamps = json_encode($timestamps);
					$tempData = json_encode($tempData);
					$humidData = json_encode($humidData);
					$airData = json_encode($airData);
					
					echo "
					<div class='card'>
						<h3>$l ($c)</h3>
						<br>
						<h5>Temperature</h5>
						<canvas id='TempCanvas$di'></canvas>
						<br>
						<h5>Humidity</h5>
						<canvas id='HumidCanvas$di'></canvas>
						<br>
						<h5>Air Quality</h5>
						<canvas id='AirCanvas$di'></canvas>
					</div>
					<script>
						// temperature
						var TempData$di = {
							labels: $timestamps,

							datasets:[{
								label:'Temperature',
								data: $tempData,
								borderColor:'blue'
							}]
						};

						var TempCanvas$di = document.getElementById('TempCanvas$di');
						var TempChart$di = new Chart(TempCanvas$di,{
							type:'line',
							data: TempData$di
						});
						
						// humidity
						var HumidData$di = {
							labels: $timestamps,

							datasets:[{
								label:'Humidity',
								data: $humidData,
								borderColor:'red'
							}]
						};

						var HumidCanvas$di = document.getElementById('HumidCanvas$di');
						var HumidChart$di = new Chart(HumidCanvas$di,{
							type:'line',
							data: HumidData$di
						});
						
						// Air Quality
						var AirData$di = {
							labels: $timestamps,

							datasets:[{
								label:'Air Quality',
								data: $airData,
								borderColor:'green'
							}]
						};

						var AirCanvas$di = document.getElementById('AirCanvas$di');
						var AirChart$di = new Chart(AirCanvas$di,{
							type:'line',
							data: AirData$di
						});
					</script>
					";
					
				}
			?>
		 </div>
		 </div>

	</body>
	
		<script type="text/javascript">	
				jQuery(document.links) .filter(function() { return this.hostname != window.location.hostname; }) .attr('target', '_blank'); 
		</script>	
		
		<script>
			function w3_open() {
			  document.getElementById("mySidebar").style.display = "block";
			}

			function w3_close() {
			  document.getElementById("mySidebar").style.display = "none";
			}
		</script>	
		
		<script>
			function myAccFunc1() {
			  var x = document.getElementById("demoAcc1");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-blue";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-blue", "");
			  }
			}
			
						function myAccFunc2() {
			  var x = document.getElementById("demoAcc2");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-blue";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-blue", "");
			  }
			}
			
			function myDropFunc() {
			  var x = document.getElementById("demoDrop");
			  if (x.className.indexOf("w3-show") == -1) {
				x.className += " w3-show";
				x.previousElementSibling.className += " w3-green";
			  } else { 
				x.className = x.className.replace(" w3-show", "");
				x.previousElementSibling.className = 
				x.previousElementSibling.className.replace(" w3-green", "");
			  }
			}
		</script>		
	</html>


