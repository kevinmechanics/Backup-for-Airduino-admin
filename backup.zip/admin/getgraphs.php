<?php
function getAllData($temperature,$humidity,$airquality,$device_id){
	
		// Get data from DB
	$temp_data = $temperature->getLastFifty($device_id);
	$humid_data = $humidity->getLastFifty($device_id);
	$airqual_data = $airquality->getLastFifty($device_id);

	
	// Create an empty array for timestamp
	$data = array();
	$times = array();

	// loop for timestamps
	foreach($temp_data as $d){
		$ts = $d['timestamp'];
		if(!in_array($ts,$times)) $times[] = $ts;
	}

	foreach($humid_data as $d){
		$ts = $d['timestamp'];
		if(!in_array($ts,$times)) $times[] = $ts;
	}

	foreach($airqual_data as $d){
		$ts = $d['timestamp'];
		if(!in_array($ts,$times)) $times[] = $ts;
	}

	// LOOP TO PREPARE FINAL DATA
	foreach($times as $t){
		$prep_ar = array();
		
		// Get timestamp from array
		$ts = $t;
		
		$p_tid = "";
		$p_t = "";
		$p_hid = "";
		$p_h = "";
		$p_aid = "";
		$p_av = "";
		$p_ad = "";

		// Temperature
		foreach($temp_data as $d){
			if($d['timestamp'] == $ts){
				$p_tid = $d['id'];
				$p_t = $d['value'];
			}
		}
		
		// Humidity
		foreach($humid_data as $d){
			if($d['timestamp'] == $ts){
				$p_hid = $d['id'];
				$p_h = $d['value'];
			}
		}
		
		// Air Quality
		//print_r($airqual_data);
		foreach($airqual_data as $d){
			if($d['timestamp'] == $ts){
				$p_aid = $d['id'];
				$p_av = $d['value'];
				$p_ad = $d['description'];

			}
		}
		
		$prep_ar = array(
			"device_id"=>$device_id,
			"timestamp"=>$ts,
			"temperature_id"=>$p_tid,
			"temperature"=>$p_t,
			"humidity_id"=>$p_hid,
			"humidity"=>$p_h,
			"air_id"=>$p_aid,
			"air_value"=>$p_av,
			"air_description"=>$p_ad
		);
		
		$data[] = $prep_ar;
		
	}

	return $data;
}



?>