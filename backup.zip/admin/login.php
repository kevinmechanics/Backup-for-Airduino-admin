<?php
session_start();

$msg = "";

if(!empty($_POST['username'])){
	$username = $_POST['username'];
	$password = $_POST['password'];	
	
	require_once("../_system/keys.php");
	require_once('../_system/db.php');
	require_once('../class/Admin.class.php');
	
	$admin = new Admin($mysqli);
	
	$array = Array(
		"username"=>$username,
		"password"=>$password
	);
	
	$result = $admin->verifyCredentials($array);
	
	if($result == True){
	
		$_SESSION["loggedin"] = True;
		$_SESSION["AdminObject"] = $admin->getByUsername($username);
		
		header("Location: index.php");
		
	} else {
		$msg = "Invalid credentials";
	}
}

?>
<!Doctype html>
<html>
	<head>
		<link rel="icon" type="image/png" href="/static/logo.png">
		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
		<title>Admin - Airduino</title>
		<meta charset="UTF-8">
        <meta name="theme-color" content="#1E90FF">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" href="/admin/styles/style.css">
		<script type="text/javascript" src="/export/assets/js/jquery-3.3.1.min.js"></script>

	</head>
	<body>
	<div class="splashscreen" style="padding-top:18%">
		<center>
		<h1 style="color:white; font-size:35pt;">Airduino</h1>
		</center>
	</div>
	<center>
	    
	<style>
        #text {display: none;color:red}
    </style>
    
    <div class="col s12 m9">
		<div class="card">
		<div class="container">
		<div class="card-image">
					<center>
						<img src="/static/splash.png" width="200px">
					</center>
		 </div>			
			<p><?php if($msg) echo $msg; ?></p>
			
			<form method="POST" style="width: 60%">
				<input class="pulse"type="text" name="username" placeholder="Username" style="width:100%; margin-bottom:15px; box-sizing: border-box;"><br>
				<input class="pulse"type="password" name="password" placeholder="Password" id="myInput" style="width:100%; box-sizing: border-box;"><br>
				<div style="display: flex; justify-content: space-between">
				    
				<label style="text-align: left;" ><input type="checkbox" onclick="myFunction()">Show Password</label>
				
				<label id="text" style="float: right">Caps lock enabled</label>    
				</div>
				
				<br>
				<center>
				<button type="submit" class="btn btnhover">Login</button>
				</center>
			</form>
			</div>
			</div>
		</div>
	</body>
	
</html>
<script>
$(document).ready(()=>{
	
	$(".splashscreen").fadeOut();
	
});
</script>

<script>
function myFunction() {
  var x = document.getElementById("myInput");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>

<script>
var input = document.getElementById("myInput");
var text = document.getElementById("text");
input.addEventListener("keyup", function(event) {

if (event.getModifierState("CapsLock")) {
    text.style.display = "inline";
  } else {
    text.style.display = "none"
  }
});
</script>