<?php include("_header.php"); ?>
				<div class="col s9">
					<h3>Newsfeed</h3> <a href="#!" class="btn btn_small">REST</a>
					
					<p>
						Accessible through https://airduino-ph.000webhostapp.com/api/newsfeed<br>
							<br>
							<br>
							<b>/get.php</b> <span class="btn btn_small">GET</span><br>
								Get a single newsfeed entry.<br>
								<br>
								<i>Parameters:</i><br><br>
									○ id <span class="btn btn_small" style="background-color:gray;">Integer</span> - ID of the given entry.<br>
							<br>
							<br>
							<b>/getAll.php</b> <span class="btn btn_small">GET</span><br>
								Get all entries from newest to oldest.<br>
								<br>
						</p>
					
</div>
<?php include("_footer.php"); ?>